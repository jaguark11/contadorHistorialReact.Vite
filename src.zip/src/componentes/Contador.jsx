import React, { useState, useEffect } from 'react';

const Contador = () => {
  const [contador, setContador] = useState(0);
  const [historial, setHistorial] = useState([]);

  useEffect(() => {
    if (contador !== 0) {
      setHistorial((prevHistorial) => [...prevHistorial, contador]);
    }
  }, [contador]);

  const incrementar = () => setContador(contador + 1);
  const reiniciar = () => {
    setContador(0);
    setHistorial([]);
  };

  const eliminarElemento = (indice) => {
    setHistorial((prevHistorial) =>
      prevHistorial.filter((_, i) => i !== indice)
    );
  };

  return (
    <div>
      <h2>Contador: {contador}</h2>
      <button onClick={incrementar}>Incrementar</button>
      <button onClick={reiniciar}>Reiniciar</button>
      <h3>Historial:</h3>
      <ul>
        {historial.map((valor, indice) => (
          <li key={indice}>
            {valor}{' '}
            <button onClick={() => eliminarElemento(indice)}>Eliminar</button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Contador;
