import React from 'react';
import Contador from './componentes/Contador'; // Asegúrate de que la ruta sea correcta
import './App.css';

function App() {
  return (
    <div className="App">
      <h1>Contador de Clics</h1>
      <Contador />
    </div>
  );
}

export default App;
